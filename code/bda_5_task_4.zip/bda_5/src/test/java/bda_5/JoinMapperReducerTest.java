package bda_5;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mrunit.mapreduce.MapDriver;
import org.apache.hadoop.mrunit.mapreduce.ReduceDriver;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.util.Arrays;

@PowerMockIgnore({"javax.management.", "com.sun.org.apache.xerces.", "javax.xml.", "org.xml.", "org.w3c.dom.", "com.sun.org.apache.xalan.", "javax.activation.*"})
public class JoinMapperReducerTest {
    private MapDriver<LongWritable, Text, Text, Text> mapDriver;
    private ReduceDriver<Text, Text, Text, Text> reduceDriver;

    @Before
    public void setUp() {
        JoinMapper mapper = new JoinMapper();
        JoinReducer reducer = new JoinReducer();
        mapDriver = MapDriver.newMapDriver(mapper);
        reduceDriver = ReduceDriver.newReduceDriver(reducer);
    }

    @Test
    public void testMapper() throws IOException
    {
        // Sample input line from dataset 1
        mapDriver.withInput(new LongWritable(1), new Text("3/31/2011,HOMICIDE,30-39,M,BLK,1"));
        mapDriver.withInput(new LongWritable(2), new Text("5/16/2008 23:46,9200 S RACINE AVE,ALLEY,WASHINGTON HEIGHTS,HOMICIDE,40-49,M,BLK,YES"));
        // Expected output after mapping
        mapDriver.withOutput(new Text("HOMICIDE"), new Text("D1\t3/31/2011,HOMICIDE,30-39,M,BLK,1"));
        mapDriver.withOutput(new Text("HOMICIDE"), new Text("D2\t5/16/2008 23:46,9200 S RACINE AVE,ALLEY,WASHINGTON HEIGHTS,HOMICIDE,40-49,M,BLK,YES"));
        mapDriver.runTest();
    }
}

