package bda_5;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class JoinRunner
{
    public static void main(String[] args) throws Exception
    {
        if (args.length != 3)
        {
            System.err.println("requires 3 arguments - input datasets and output directory");
            System.exit(-1);
        }
        // new configuration
        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "JoinDatasets");
        // setting the runnner class
        job.setJarByClass(JoinRunner.class);
        // setting the mapper class
        job.setMapperClass(JoinMapper.class);
        // setting the reducer class
        job.setReducerClass(JoinReducer.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);
        // first argument is for dataset1, 2nd argument is for dataset2
        FileInputFormat.addInputPaths(job, args[0]);
        FileInputFormat.addInputPaths(job, args[1]);
        // third argument is the output path
        FileOutputFormat.setOutputPath(job, new Path(args[2]));
        // wait for job completetion
        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}