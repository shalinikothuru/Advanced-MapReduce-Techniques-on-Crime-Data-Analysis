package bda_5;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import java.io.IOException;

public class JoinMapper extends Mapper<LongWritable, Text, Text, Text>
{
    private Text joinKey = new Text();
    private Text taggedValue = new Text();
    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        String[] tokens = value.toString().split(",");
        String victimizationPrimary;
        String datasetTag;
        if (tokens.length == 6)
        {
            // dataset 1
            victimizationPrimary = tokens[1].trim();
            datasetTag = "D1";
        }
        else if (tokens.length == 9)
        {
            // dataset 2
            victimizationPrimary = tokens[4].trim();
            datasetTag = "D2";
        } else {
            return;
        }
        // appending the dataset tag to the value
        taggedValue.set(datasetTag + "\t" + value.toString());
        joinKey.set(victimizationPrimary);
        context.write(joinKey, taggedValue);
    }
}
