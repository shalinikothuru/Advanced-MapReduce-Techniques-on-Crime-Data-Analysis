package bda_5;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class JoinReducer extends Reducer<Text, Text, Text, Text>
{
    public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException
    {
        List<String> dataset1Records = new ArrayList<>();
        List<String> dataset2Records = new ArrayList<>();
        for (Text val : values)
        {
            String value = val.toString();
            if (value.startsWith("D1\t"))
            {
                // Remove tag and common column
                dataset1Records.add(value.substring(3).replaceAll(key.toString() + ",", ""));
            } else if (value.startsWith("D2\t"))
            {
                // Remove tag and common column
                dataset2Records.add(value.substring(3).replaceAll(key.toString() + ",", ""));
            }
        }
        // performing the join for each combination of records from dataset1 and dataset2
        for (String record1 : dataset1Records)
        {
            for (String record2 : dataset2Records)
            {
                context.write(key, new Text(record1 + "\t" + record2));
            }
        }
    }
}