package bda_5;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

public class CustomPartitioner extends Partitioner<CompositeKey, Text>
{
    @Override
    public int getPartition(CompositeKey key, Text value, int numReduceTasks) {
        return (key.getVictimizationPrimary().hashCode() & Integer.MAX_VALUE) % numReduceTasks;
    }
}


