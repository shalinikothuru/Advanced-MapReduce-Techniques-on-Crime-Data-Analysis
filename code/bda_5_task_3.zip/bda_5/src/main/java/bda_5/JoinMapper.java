package bda_5;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import java.io.IOException;

public class JoinMapper extends Mapper<LongWritable, Text, CompositeKey, Text>
{
    private CompositeKey compositeKey = new CompositeKey();
    private Text taggedValue = new Text();
    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException
    {
        String[] tokens = value.toString().split(",");
        String victimizationPrimary;
        String age;
        String datasetTag;
        String outputValue;
        if (tokens.length == 6)
        {
            // dataset 1
            victimizationPrimary = tokens[1].trim();
            age = tokens[2].trim();
            datasetTag = "D1";
            outputValue = value.toString();
        }
        else if (tokens.length == 9)
        {
            // dataset 2
            victimizationPrimary = tokens[4].trim();
            age = tokens[5].trim();
            datasetTag = "D2";
            // the output values excluding the common columns
            outputValue = String.join(",", tokens[0], tokens[1], tokens[2], tokens[3], tokens[5],tokens[6], tokens[7], tokens[8]);
        }
        else
        {
            return;
        }
        compositeKey.set(new Text(victimizationPrimary), new Text(age));
        taggedValue.set(datasetTag + "\t" + outputValue);
        context.write(compositeKey, taggedValue);
    }
}
