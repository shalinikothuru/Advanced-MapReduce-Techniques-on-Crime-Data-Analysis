package bda_5;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class JoinReducer extends Reducer<CompositeKey, Text, CompositeKey, Text>
{
    public void reduce(CompositeKey key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
        List<String> dataset1Records = new ArrayList<>();
        List<String> dataset2Records = new ArrayList<>();
        for (Text val : values)
        {
            String value = val.toString();
            if (value.startsWith("D1\t"))
            {
                dataset1Records.add(value.substring(3));
            } else if (value.startsWith("D2\t"))
            {
                dataset2Records.add(value.substring(3));
            }
        }
        // performing the join for each combination of records from dataset1 and dataset2
        for (String record1 : dataset1Records)
        {
            for (String record2 : dataset2Records)
            {
                context.write(null, new Text(record1 + "\t" + record2));
            }
        }
    }
}
