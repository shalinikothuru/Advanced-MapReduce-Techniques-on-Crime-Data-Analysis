package bda_5;

import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;
import org.apache.hadoop.io.Text;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

public class CompositeKey implements WritableComparable<CompositeKey>
{
    private Text victimizationPrimary;
    private Text age;
    public CompositeKey() {
        set(new Text(), new Text());
    }
    public CompositeKey(String victimizationPrimary, String age) {
        set(new Text(victimizationPrimary), new Text(age));
    }
    public void set(Text victimizationPrimary, Text age)
    {
        this.victimizationPrimary = victimizationPrimary;
        this.age = age;
    }
    public Text getVictimizationPrimary() {
        return victimizationPrimary;
    }
    public Text getAge() {
        return age;
    }
    @Override
    public void write(DataOutput out) throws IOException {
        victimizationPrimary.write(out);
        age.write(out);
    }
    @Override
    public void readFields(DataInput in) throws IOException
    {
        victimizationPrimary.readFields(in);
        age.readFields(in);
    }
    @Override
    public int compareTo(CompositeKey o)
    {
        int cmp = victimizationPrimary.compareTo(o.victimizationPrimary);
        if (cmp != 0) {
            return cmp;
        }
        return age.compareTo(o.age);
    }

    @Override
    public int hashCode() {
        return victimizationPrimary.hashCode() * 163 + age.hashCode();
    }

    @Override
    public boolean equals(Object o)
    {
        if (o instanceof CompositeKey)
        {
            CompositeKey other = (CompositeKey) o;
            return victimizationPrimary.equals(other.victimizationPrimary) && age.equals(other.age);
        }
        return false;
    }

    @Override
    public String toString() {
        return victimizationPrimary + "\t" + age;
    }
}
