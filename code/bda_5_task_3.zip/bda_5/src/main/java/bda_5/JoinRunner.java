package bda_5;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

public class JoinRunner implements Tool {
    private Configuration conf;
    @Override
    public void setConf(Configuration conf)
    {
        this.conf = conf;
    }
    @Override
    public Configuration getConf()
    {
        return conf;
    }
    @Override
    public int run(String[] args) throws Exception
    {
        if (args.length != 3) {
            System.err.printf("2 input datasets and output directory\n", getClass().getSimpleName());
            ToolRunner.printGenericCommandUsage(System.err);
            return -1;
        }
        // job configuration
        Job job = Job.getInstance(getConf(), "Join and Sort");
        job.setJarByClass(getClass());
        // setting the two input paths - datasets and the output path
        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileInputFormat.addInputPath(job, new Path(args[1]));
        FileOutputFormat.setOutputPath(job, new Path(args[2]));
        job.setMapperClass(JoinMapper.class);
        job.setReducerClass(JoinReducer.class);
        job.setMapOutputKeyClass(CompositeKey.class);
        job.setMapOutputValueClass(Text.class);
        job.setOutputKeyClass(NullWritable.class);
        job.setOutputValueClass(Text.class);
        job.setPartitionerClass(CustomPartitioner.class);
        job.setGroupingComparatorClass(GroupComparator.class);
        job.setSortComparatorClass(KeyComparator.class);
        return job.waitForCompletion(true) ? 0 : 1;
    }
    public static void main(String[] args) throws Exception
    {
        int exitCode = ToolRunner.run(new JoinRunner(), args);
        System.exit(exitCode);
    }
}
